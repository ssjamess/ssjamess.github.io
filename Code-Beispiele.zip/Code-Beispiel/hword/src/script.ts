interface ScheduleCell {
    day: string;
    time: string;
    subject: string;
}

const days = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag"];
const times = ["08:00 - 10:00", "10:00 - 12:00", "13:00 - 15:00", "15:00 - 17:00"];

let schedule: ScheduleCell[][] = times.map(time => {
    return days.map(day => ({
        day: day,
        time: time,
        subject: ""
    }));
});

function createScheduleTable(): void {
    const scheduleDiv = document.getElementById("schedule");
    if (scheduleDiv) {
        scheduleDiv.innerHTML = "";

        const headerRow = document.createElement("div");
        headerRow.className = "cell";
        scheduleDiv.appendChild(headerRow);

        days.forEach(day => {
            const headerCell = document.createElement("div");
            headerCell.className = "cell";
            headerCell.innerText = day;
            scheduleDiv.appendChild(headerCell);
        });

        schedule.forEach((row, rowIndex) => {
            const timeCell = document.createElement("div");
            timeCell.className = "cell";
            timeCell.innerText = times[rowIndex];
            scheduleDiv.appendChild(timeCell);

            row.forEach(cell => {
                const cellDiv = document.createElement("div");
                cellDiv.className = "cell";

                const input = document.createElement("input");
                input.type = "text";
                input.value = cell.subject;
                input.addEventListener("input", (e) => {
                    cell.subject = (e.target as HTMLInputElement).value;
                });

                cellDiv.appendChild(input);
                scheduleDiv.appendChild(cellDiv);
            });
        });
    }
}

document.getElementById("saveBtn")?.addEventListener("click", () => {
    console.log("Gespeicherter Stundenplan :", schedule);
    alert("In der Konsole gespeicherter Stundenplan!");
});

createScheduleTable();